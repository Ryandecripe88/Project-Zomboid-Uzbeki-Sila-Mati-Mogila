# Чайная лавка

Простой магазин чая на React + Tailwind CSS.

```
cd app
npm install
npm start
```

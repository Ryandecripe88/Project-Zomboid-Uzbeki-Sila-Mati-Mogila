/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{html,js,jsx,ts,tsx}', './public/index.html'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Nunito', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        tea: {
          50: '#f6f8f1',
          100: '#e9f0dc',
          200: '#d4e3bb',
          700: '#477030',
          800: '#38592a',
        },
      },
    },
  },
  plugins: [],
}

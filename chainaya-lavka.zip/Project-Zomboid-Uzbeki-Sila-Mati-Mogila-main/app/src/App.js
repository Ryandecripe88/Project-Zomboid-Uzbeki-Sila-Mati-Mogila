import { BrowserRouter, Link, Route, Routes } from 'react-router-dom'
import Header from './Header'
import Footer from './Footer'
import Home from './Home'
import Search from './Search'
import Cart from './Cart'
import { CartProvider } from './CartContext'

const NotFound = () => (
  <div className="mx-auto max-w-6xl px-4 py-16 text-center sm:px-6">
    <h1 className="text-3xl font-extrabold text-stone-900">Страница не найдена</h1>
    <Link
      to="/"
      className="mt-6 inline-block rounded-full bg-tea-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-tea-800"
    >
      На главную
    </Link>
  </div>
)

function App() {
  return (
    <BrowserRouter>
      <CartProvider>
        <div className="flex min-h-screen flex-col">
          <Header />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/search" element={<Search />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </CartProvider>
    </BrowserRouter>
  )
}

export default App

import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useCart } from './CartContext'
import { formatPrice } from './products'
import { Stepper } from './ProductCard'

const Cart = () => {
  const { lines, total, add, decrease, remove, clear } = useCart()
  const [ordered, setOrdered] = useState(false)

  if (ordered) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 text-center sm:px-6">
        <h1 className="text-3xl font-extrabold text-stone-900">Спасибо за заказ!</h1>
        <p className="mt-2 text-stone-600">Мы свяжемся с вами, чтобы подтвердить детали.</p>
        <Link
          to="/"
          className="mt-6 inline-block rounded-full bg-tea-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-tea-800"
        >
          Вернуться в каталог
        </Link>
      </div>
    )
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 text-center sm:px-6">
        <h1 className="text-3xl font-extrabold text-stone-900">Корзина пуста</h1>
        <p className="mt-2 text-stone-600">Загляните в каталог — там есть из чего выбрать.</p>
        <Link
          to="/"
          className="mt-6 inline-block rounded-full bg-tea-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-tea-800"
        >
          Перейти в каталог
        </Link>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <h1 className="text-3xl font-extrabold text-stone-900 sm:text-4xl">Корзина</h1>

      <ul className="mt-6 divide-y divide-stone-200 rounded-xl border border-stone-200 bg-white">
        {lines.map((l) => (
          <li key={l.id} className="flex items-center gap-4 p-4">
            <img src={l.image} alt="" className="h-16 w-20 object-contain" />
            <div className="flex-1">
              <p className="font-bold text-stone-900">{l.title}</p>
              <p className="text-sm text-stone-500">{formatPrice(l.price)}</p>
            </div>
            <Stepper qty={l.qty} onMinus={() => decrease(l.id)} onPlus={() => add(l.id)} />
            <p className="hidden w-24 text-right font-bold text-stone-900 sm:block">
              {formatPrice(l.price * l.qty)}
            </p>
            <button
              onClick={() => remove(l.id)}
              aria-label={`Удалить ${l.title}`}
              className="rounded-full px-2 text-xl text-stone-400 hover:text-red-600"
            >
              ×
            </button>
          </li>
        ))}
      </ul>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
        <button onClick={clear} className="text-sm font-semibold text-stone-500 hover:text-red-600">
          Очистить корзину
        </button>
        <div className="flex items-center gap-5">
          <p className="text-lg text-stone-700">
            Итого: <span className="font-extrabold text-stone-900">{formatPrice(total)}</span>
          </p>
          <button
            onClick={() => {
              clear()
              setOrdered(true)
            }}
            className="rounded-full bg-tea-700 px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-tea-800"
          >
            Оформить заказ
          </button>
        </div>
      </div>
    </div>
  )
}

export default Cart

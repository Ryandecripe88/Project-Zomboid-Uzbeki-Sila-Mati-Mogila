import React from 'react'
import { formatPrice } from './products'
import { useCart } from './CartContext'

export const Stepper = ({ qty, onMinus, onPlus }) => (
  <div className="flex items-center rounded-full border border-tea-700 text-tea-800">
    <button
      onClick={onMinus}
      aria-label="Убрать одну штуку"
      className="h-9 w-9 rounded-full text-lg font-semibold transition hover:bg-tea-100"
    >
      −
    </button>
    <span className="min-w-[1.5rem] text-center text-sm font-bold">{qty}</span>
    <button
      onClick={onPlus}
      aria-label="Добавить ещё одну"
      className="h-9 w-9 rounded-full text-lg font-semibold transition hover:bg-tea-100"
    >
      +
    </button>
  </div>
)

const ProductCard = ({ product }) => {
  const { items, add, decrease } = useCart()
  const qty = items[product.id] || 0

  return (
    <article className="flex flex-col overflow-hidden rounded-xl border border-stone-200 bg-white">
      <div className="flex h-44 items-center justify-center bg-white p-4">
        <img
          src={product.image}
          alt={product.title}
          className="max-h-full max-w-full object-contain"
        />
      </div>

      <div className="flex flex-1 flex-col border-t border-stone-100 p-4">
        <h2 className="text-base font-bold text-stone-900">{product.title}</h2>
        <p className="mt-1 flex-1 text-sm leading-snug text-stone-600">{product.description}</p>

        <div className="mt-4 flex items-center justify-between gap-2">
          <span className="text-lg font-extrabold text-stone-900">{formatPrice(product.price)}</span>

          {qty === 0 ? (
            <button
              onClick={() => add(product.id)}
              className="rounded-full bg-tea-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-tea-800"
            >
              В корзину
            </button>
          ) : (
            <Stepper qty={qty} onMinus={() => decrease(product.id)} onPlus={() => add(product.id)} />
          )}
        </div>
      </div>
    </article>
  )
}

export default ProductCard

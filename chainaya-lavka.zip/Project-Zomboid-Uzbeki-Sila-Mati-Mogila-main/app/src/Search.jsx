import React, { useState } from 'react'
import ProductCard from './ProductCard'
import { PRODUCTS } from './products'

const Search = () => {
  const [query, setQuery] = useState('')
  const q = query.trim().toLowerCase()
  const found = q
    ? PRODUCTS.filter((p) => `${p.title} ${p.description}`.toLowerCase().includes(q))
    : PRODUCTS

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <h1 className="text-3xl font-extrabold text-stone-900 sm:text-4xl">Поиск</h1>

      <div className="mt-5 flex max-w-xl gap-2">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Например: матча или чайник"
          className="w-full rounded-full border border-stone-300 bg-white px-5 py-2.5 text-sm outline-none focus:border-tea-700"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="rounded-full border border-stone-300 bg-white px-4 text-sm font-semibold text-stone-700 hover:border-tea-700"
          >
            Сбросить
          </button>
        )}
      </div>

      {found.length === 0 ? (
        <p className="mt-8 text-stone-600">Ничего не нашли. Попробуйте другое слово.</p>
      ) : (
        <section className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {found.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </section>
      )}
    </div>
  )
}

export default Search

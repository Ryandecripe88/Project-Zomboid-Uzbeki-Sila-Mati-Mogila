import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="mt-16 border-t border-stone-200 bg-white">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
        <div className="md:col-span-1">
          <h2 className="text-lg font-extrabold text-stone-900">О нашей лавке</h2>
          <p className="mt-3 text-sm leading-relaxed text-stone-600">
            Привозим чай напрямую с плантаций Китая, Индии и Японии и подбираем посуду, в которой
            вкус раскрывается лучше всего.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-bold text-stone-900">Разделы</h3>
          <ul className="mt-3 space-y-2 text-sm text-stone-600">
            <li>
              <Link to="/" className="hover:text-tea-700">Каталог</Link>
            </li>
            <li>
              <Link to="/search" className="hover:text-tea-700">Поиск</Link>
            </li>
            <li>
              <Link to="/cart" className="hover:text-tea-700">Корзина</Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-bold text-stone-900">Связаться с нами</h3>
          <p className="mt-3 text-sm text-stone-600">
            Поможем выбрать чай или подарочный набор.
          </p>
          <a
            href="mailto:hello@example.com"
            className="mt-4 inline-block rounded-full border border-tea-700 px-5 py-2 text-sm font-semibold text-tea-700 transition hover:bg-tea-700 hover:text-white"
          >
            Написать нам
          </a>
        </div>
      </div>

      <div className="border-t border-stone-200 py-4 text-center text-xs text-stone-500">
        © {new Date().getFullYear()} Чайная лавка
      </div>
    </footer>
  )
}

export default Footer

import React, { useState } from 'react'
import ProductCard from './ProductCard'
import { CATEGORIES, PRODUCTS } from './products'

const Home = () => {
  const [category, setCategory] = useState('all')
  const visible = category === 'all' ? PRODUCTS : PRODUCTS.filter((p) => p.category === category)

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <section className="mb-8">
        <h1 className="text-3xl font-extrabold text-stone-900 sm:text-4xl">Выберите товар</h1>
        <p className="mt-2 max-w-xl text-stone-600">
          Чай, чайники и посуда для каждого дня и для подарков.
        </p>
      </section>

      <div className="mb-6 flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setCategory(c.id)}
            className={`rounded-full border px-4 py-1.5 text-sm font-semibold transition ${
              category === c.id
                ? 'border-tea-700 bg-tea-700 text-white'
                : 'border-stone-300 bg-white text-stone-700 hover:border-tea-700'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <section className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {visible.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </section>
    </div>
  )
}

export default Home

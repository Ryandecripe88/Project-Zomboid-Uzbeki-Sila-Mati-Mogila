import React, { createContext, useContext, useMemo, useState } from 'react'
import { PRODUCTS } from './products'

const CartContext = createContext(null)

export const CartProvider = ({ children }) => {
  // { [productId]: количество }
  const [items, setItems] = useState({})

  const add = (id) => setItems((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 }))

  const decrease = (id) =>
    setItems((prev) => {
      const next = { ...prev }
      if (next[id] > 1) next[id] -= 1
      else delete next[id]
      return next
    })

  const remove = (id) =>
    setItems((prev) => {
      const next = { ...prev }
      delete next[id]
      return next
    })

  const clear = () => setItems({})

  const value = useMemo(() => {
    const lines = PRODUCTS.filter((p) => items[p.id]).map((p) => ({
      ...p,
      qty: items[p.id],
    }))
    return {
      items,
      lines,
      count: lines.reduce((sum, l) => sum + l.qty, 0),
      total: lines.reduce((sum, l) => sum + l.qty * l.price, 0),
      add,
      decrease,
      remove,
      clear,
    }
  }, [items])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export const useCart = () => useContext(CartContext)

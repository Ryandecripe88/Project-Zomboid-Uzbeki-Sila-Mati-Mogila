import IMG1 from './images/product-1.png'
import IMG2 from './images/product-2.png'
import IMG3 from './images/product-3.png'
import IMG4 from './images/product-4.png'
import IMG5 from './images/product-5.png'
import IMG6 from './images/product-6.png'
import IMG7 from './images/product-7.png'
import IMG8 from './images/product-8.png'
import IMG9 from './images/product-9.png'
import IMG10 from './images/product-10.png'

export const CATEGORIES = [
  { id: 'all', label: 'Всё' },
  { id: 'tea', label: 'Чай' },
  { id: 'ware', label: 'Посуда' },
]

export const PRODUCTS = [
  { id: 1, category: 'tea', title: 'Зелёный чай', description: 'Свежий, травянистый вкус с лёгкой терпкостью и весенним ароматом.', price: 450, image: IMG1 },
  { id: 2, category: 'tea', title: 'Чёрный чай', description: 'Насыщенный, глубокий вкус с медовыми и древесными нотками.', price: 390, image: IMG2 },
  { id: 3, category: 'tea', title: 'Красный чай', description: 'Мягкий, согревающий вкус с фруктовыми и медовыми оттенками.', price: 520, image: IMG3 },
  { id: 4, category: 'ware', title: 'Чайник металлический', description: 'Прочный чайник из нержавеющей стали для заваривания любого чая.', price: 1790, image: IMG4 },
  { id: 5, category: 'ware', title: 'Чайник керамический', description: 'Удобная ручка, долго сохраняет тепло напитка.', price: 1450, image: IMG5 },
  { id: 6, category: 'tea', title: 'Тропический чай', description: 'Ароматный купаж с кусочками манго, ананаса и лепестками цветов.', price: 480, image: IMG6 },
  { id: 7, category: 'tea', title: 'Пуэр с розой', description: 'Выдержанный шу пуэр с нежным цветочным ароматом бутонов розы.', price: 650, image: IMG7 },
  { id: 8, category: 'tea', title: 'Матча зелёная', description: 'Японский порошковый чай с ярким вкусом и бодрящим эффектом.', price: 920, image: IMG8 },
  { id: 9, category: 'ware', title: 'Набор пиал (4 шт)', description: 'Классические фарфоровые пиалы для традиционного чаепития.', price: 890, image: IMG9 },
  { id: 10, category: 'tea', title: 'Набор «Ассорти»', description: 'Подарочный набор из 6 популярных сортов листового чая.', price: 1390, image: IMG10 },
]

export const formatPrice = (value) => `${value.toLocaleString('ru-RU')} ₽`

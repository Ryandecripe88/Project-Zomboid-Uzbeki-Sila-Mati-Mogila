import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import LOGO from './images/logo.svg'
import { useCart } from './CartContext'

const navClass = ({ isActive }) =>
  `rounded-full px-4 py-2 text-sm font-semibold transition ${
    isActive ? 'bg-tea-100 text-tea-800' : 'text-stone-600 hover:bg-tea-100/60'
  }`

const Header = () => {
  const { count } = useCart()

  return (
    <header className="sticky top-0 z-10 border-b border-stone-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center gap-3">
          <img src={LOGO} alt="" className="h-10 w-10" />
          <span className="leading-tight">
            <span className="block text-lg font-extrabold text-stone-900">Чайная лавка</span>
            <span className="hidden text-xs text-stone-500 sm:block">Листовой чай и посуда</span>
          </span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          <NavLink to="/" end className={navClass}>
            Каталог
          </NavLink>
          <NavLink to="/search" className={navClass}>
            Поиск
          </NavLink>
          <NavLink
            to="/cart"
            className="ml-1 flex items-center gap-2 rounded-full bg-tea-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-tea-800"
          >
            Корзина
            <span className="min-w-[1.5rem] rounded-full bg-white px-1.5 text-center text-xs font-bold text-tea-800">
              {count}
            </span>
          </NavLink>
        </nav>
      </div>
    </header>
  )
}

export default Header
